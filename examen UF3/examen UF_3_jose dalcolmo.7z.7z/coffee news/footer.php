<?php

    echo "<p class='m-0 text-center text-white'text-center>
    AVISO LEGAL:<br>
    De acuerdo con lo que establece la Ley Orgánica de Protección de Datos 
                    (LOPD) 15/1999, le informamos que los datos personales recogidos en este 
                    formulario serán incluidos en un fichero bajo la responsabilidad de 
                    YOURSELF, S.L.. Puede ejercer sus derechos de acceso, rectificación, 
                    cancelación y oposición en: YOURSELF, S.L., Calle NS/NC Nº 007, 08000 – JAEN. 
                    Your Website 2019</>";
                    ?>